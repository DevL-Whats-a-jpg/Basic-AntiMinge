Just simply place the .lua in the servers auto run file
I left comments indicating what most the stuff does in there if youre new to coding in gmod but its all fairly simple

If you encounter problem(s) that you somehow cant fix you can contact my discord (DevL#2274)